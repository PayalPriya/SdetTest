package stepDefination;

import static io.restassured.RestAssured.given;

import java.util.LinkedHashMap;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import junit.framework.Assert;

public class foreign_exchange_rates_steps {

	@When("I send request to get latest exchange rates")
	public void i_send_request_to_get_latest_exchange_rates() {
		RestAssured.baseURI = api.api_basics.URI;
		String exchangeRateresponse = given().log().all().when().get(api.api_basics.resource1).then().assertThat()
				.statusCode(200).extract().response().asString();
		JsonPath js1 = file.JsonData.rawToJson(exchangeRateresponse);
		Assert.assertNotNull(js1.get("rates"));
	}

	@When("I send request to get latest exchange rates with invalid URL")
	public void i_send_request_to_get_latest_exchange_rates_with_invalid_url() {
		RestAssured.baseURI = api.api_basics.URI;
		String exchangeRateresponse = given().log().all().when().get(api.api_basics.invalidresource).then().assertThat()
				.statusCode(400).extract().response().asString();
		JsonPath js1 = file.JsonData.rawToJson(exchangeRateresponse);
		String errormessage = js1.get("error");
		Assert.assertEquals("time data 'api' does not match format '%Y-%m-%d'", errormessage);
	}

	@When("I send request to get latest exchange rates for {string} having value {string} and {string}")
	public void i_send_request_to_get_latest_exchange_rates_for_given_parameter(String parameter, String value1,
			String value2) {
		RestAssured.baseURI = api.api_basics.URI;
		String parametervalues = value1 + "," + value2;
		String exchangeRateresponse = given().log().all().queryParam(parameter, parametervalues).when()
				.get(api.api_basics.resource1).then().assertThat().statusCode(200).extract().response().asString();
		JsonPath js1 = file.JsonData.rawToJson(exchangeRateresponse);
		LinkedHashMap<Character, Integer> ratesofParameter = js1.get("rates");
		System.out.println(ratesofParameter.get(value1));
		Assert.assertTrue(ratesofParameter.containsKey(value1));
		Assert.assertTrue(ratesofParameter.containsKey(value2));

	}

	@When("I send request to get latest exchange rates for {string} having value {string}")
	public void i_send_request_to_get_latest_exchange_rates_for_given_parameter(String parameter, String value) {
		RestAssured.baseURI = api.api_basics.URI;
		String exchangeRateresponse = given().log().all().queryParam(parameter, value).when()
				.get(api.api_basics.resource1).then().assertThat().statusCode(200).extract().response().asString();
		JsonPath js1 = file.JsonData.rawToJson(exchangeRateresponse);
		String base = js1.get("base");
		Assert.assertEquals(value, base);

	}

	@When("I send request to get latest exchange rates for base and symbols having value {string} and {string}")
	public void i_send_request_to_get_latest_exchange_rates_for_base_and_symbol(String value1, String value2) {
		RestAssured.baseURI = api.api_basics.URI;
		String exchangeRateresponse = given().log().all().queryParam("base", value1).queryParam("symbols", value2)
				.when().get(api.api_basics.resource1).then().assertThat().statusCode(200).extract().response()
				.asString();
		JsonPath js1 = file.JsonData.rawToJson(exchangeRateresponse);
		LinkedHashMap<Character, Integer> ratesofParameter = js1.get("rates");
		System.out.println(ratesofParameter.get(value1));
		String base = js1.get("base");
		Assert.assertEquals(value1, base);
		Assert.assertTrue(ratesofParameter.containsKey(value2));

	}

}

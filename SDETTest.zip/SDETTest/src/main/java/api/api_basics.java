package api;

public class api_basics {

public static String URI="https://api.ratesapi.io";
public static String resource1="api/latest";
public static String invalidresource="api";

}
